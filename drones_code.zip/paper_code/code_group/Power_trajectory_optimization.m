function [pow,tra_x,tra_y,value_N] = Power_trajectory_optimization(pow_0,x_0,y_0,...
    acc_u,acc_v,acc_fm,D_iBSm, G_BSm,H_cons_uav,...
    users_x,users_y,h_uav,BS_loc,P_max,B_uav,n0,area,v_max,dT,drone_mass,...
    mu_tra_max,mu_pow_max,a_env, b_env,shadow_fading,G_r,G_t,mu_value_max,c_pow_tra_max)

% pow_0                              (num_users+1) x num_drones x N
% x_0                             num_drones x N
% y_0                            num_drones x N
% optimal_acc_u                 num_users x num_drones x N
% D_iBSm                      (num_users+1) x num_drones x N
% G_BSm                       num_drones x 1 x N
% F_BSm                          num_drones x 1 x N
% H_cons_uav                  标量
% C_im                         num_users x num_drones x N
% users_x                         %num_users x N
% users_y                            %num_users x N
% h_uav                       标量
% BS_loc                       1x2
% optimal_acc_v            num_users x num_users x N
% P_max                      标量
% B_uav                   标量
% n0                     标量
% area                   标量
% d_min                     标量
% v_max                    标量
% dT                      标量
% drone_mass             标量
c_pow_tra = 0;
SNR_ln_0 = 0;
value_pre = 0;

[num_users, num_drones,N] = size(acc_u);

[SNR_i_pre,value_i_pre,~] = value_calculation_N_fun(pow_0 * P_max,x_0,y_0,acc_u,acc_fm,acc_v,...
    users_x,users_y,h_uav,a_env, b_env,shadow_fading,G_r,G_t,B_uav,n0);
value_i_pre;
value_N =value_i_pre;

pow_0 = (num_drones / (num_users + num_drones)) * ones(num_users + 1, num_drones, N);
pow_0(1:num_users,:,:) = pow_0(1:num_users,:,:) .* acc_u;

while 1

    [pow,tra_x,tra_y,SNR_ln] = Power_Tra_Opt(pow_0,x_0,y_0,...
        acc_u,D_iBSm, G_BSm,H_cons_uav,...
        users_x,users_y,h_uav,BS_loc,acc_v,P_max,B_uav,n0,area,v_max,dT,drone_mass);

    % [pow,tra_x,tra_y,SNR_ln] = Power_Tra_Opt_improve(pow_0,x_0,y_0,...
    %     acc_u,D_iBSm, G_BSm,H_cons_uav,...
    %     users_x,users_y,h_uav,BS_loc,acc_v,P_max,B_uav,n0,area,v_max,dT,drone_mass);

    %pow结果可能过小导致显示0，其实是有值

    c_pow_tra = c_pow_tra+1;
    mu_pow = pow_0 - pow;
    norm_mu_pow = norm(mu_pow(:));
    mu_x = x_0 - tra_x;
    mu_y = y_0 - tra_y;
    mu_tra = [mu_x,mu_y];
    norm_mu_tra = norm(mu_tra(:));
    mu_SNR_ln = SNR_ln - SNR_ln_0;

    %计算用户理论最小信噪比和通信速率

    SNR = exp(SNR_ln);  %子问题的理论信噪比结果
    value = B_uav * log2(1+SNR);  %子问题的理论用户速率结果

    %%计算用户实际最小信噪比和通信速率

    [SNR_i,value_i,~] = value_calculation_N_fun(pow * P_max,tra_x,tra_y,acc_u,acc_fm,acc_v,...
        users_x,users_y,h_uav,a_env, b_env,shadow_fading,G_r,G_t,B_uav,n0);
    SNR_i;
    value_i;

    value_N = [value_N,value_i];

    mu_value = value - value_pre;

    %%计算无人机基站间实际最小信噪比和通信速率
    power_BS = pow(num_users+1,:,:);

    d_BSm_matrix = zeros(1,num_drones, N);
    for t = 1:N
        % 获取第 t 个时隙的无人机位置
        uav_x_t = tra_x(:, t);      % num_drones x 1
        uav_y_t = tra_y(:, t);      % num_drones x 1

        % 计算坐标差
        % 使用 MATLAB 的隐式扩展（R2016b 及以上版本）
        delta_x = uav_x_t - BS_loc(1,1);  % num_drones x 1
        delta_y = uav_y_t - BS_loc(1,2);  % num_drones x 1

        % 计算距离矩阵
        d_BSm_matrix(:, :, t) = (sqrt(delta_x.^2 + delta_y.^2 + h_uav^2))';  % 1 x num_drones
    end

    [~ ,g_BSm_matrix] = ATG_Channel_Model(d_BSm_matrix, h_uav, acc_fm(num_users+1,:,:), a_env, b_env,shadow_fading,G_r,G_t);

    SNR_BS_N = (P_max / (n0 * B_uav)) * (g_BSm_matrix .* power_BS);  %1 x num_drones x N
    SNR_BS = min(SNR_BS_N(:));  %功率轨迹优化后实际信噪比
    value_BS = B_uav * log2(1+SNR_BS);  %功率轨迹优化后实际通信速率



    if (norm_mu_pow<=mu_pow_max) ||(norm_mu_tra<=mu_tra_max)||(c_pow_tra==c_pow_tra_max)||(mu_value<=mu_value_max)
        break;

    end

    pow_0 = pow;
    x_0 = tra_x;
    y_0 = tra_y;
    SNR_ln_0 = SNR_ln;
    value_i_pre = value_i;
    value_pre = value;
end

end
