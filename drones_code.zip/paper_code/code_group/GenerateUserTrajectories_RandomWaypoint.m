%function [users_x, users_y] = GenerateUserTrajectories_RandomWaypoint()

clear; 
close all; 
clc;

% 参数设置
    num_users = 24;         % 用户数量
    num_time_slots = 100;   % 时间槽数量
    area_size = 1000;       % 区域大小（米）
    v_min = 1;              % 最小速度（米/秒）
    v_max = 5;              % 最大速度（米/秒）
    pause_time = 0;         % 用户在路点的停留时间（时间槽数量）
    delta_t = 1;            % 时间间隔（秒）
    
    % 初始化位置矩阵
    users_x = zeros(num_users, num_time_slots);
    users_y = zeros(num_users, num_time_slots);
    
    % 初始位置（在区域内随机分布）
    users_x(:,1) = area_size * rand(num_users,1);
    users_y(:,1) = area_size * rand(num_users,1);
    
    % 为每个用户初始化目标点、速度和剩余停留时间
    dest_x = area_size * rand(num_users,1);
    dest_y = area_size * rand(num_users,1);
    v = v_min + (v_max - v_min) * rand(num_users,1);
    pause_remaining = zeros(num_users,1);
    
    for t = 2:num_time_slots
        for user = 1:num_users
            if pause_remaining(user) > 0
                % 用户正在停留
                users_x(user,t) = users_x(user,t-1);
                users_y(user,t) = users_y(user,t-1);
                pause_remaining(user) = pause_remaining(user) - 1;
            else
                % 计算到目标点的距离
                dist = sqrt((dest_x(user) - users_x(user,t-1))^2 + (dest_y(user) - users_y(user,t-1))^2);
                
                if dist < v(user) * delta_t
                    % 到达目标点，设置新的目标点和速度
                    users_x(user,t) = dest_x(user);
                    users_y(user,t) = dest_y(user);
                    pause_remaining(user) = pause_time;
                    dest_x(user) = area_size * rand();
                    dest_y(user) = area_size * rand();
                    v(user) = v_min + (v_max - v_min) * rand();
                else
                    % 计算移动方向
                    dir_x = (dest_x(user) - users_x(user,t-1)) / dist;
                    dir_y = (dest_y(user) - users_y(user,t-1)) / dist;
                    % 更新位置
                    users_x(user,t) = users_x(user,t-1) + dir_x * v(user) * delta_t;
                    users_y(user,t) = users_y(user,t-1) + dir_y * v(user) * delta_t;
                end
            end
        end
    end
    
    % 保存数据到文件（可选）
    save('user_trajectories.mat', 'users_x', 'users_y');



% 可视化前5个用户的轨迹
figure;
hold on;
colors = lines(num_users);
for i = 1:min(num_users,5)
    plot(users_x(i,:), users_y(i,:), 'Color', colors(i,:), 'LineWidth', 1.5);
end
title('随机路点模型下的用户轨迹');
xlabel('X 坐标（米）');
ylabel('Y 坐标（米）');
xlim([0 area_size]);
ylim([0 area_size]);
grid on;
hold off;













