
clear; 
close all; 
clc;


c =1:10;

% 定义数据

%5,9
value_1 = 1.0e+07 * [0.0458    2.6189    2.6010    2.5752    2.5726    2.5729    2.5729    2.5729    2.5729    2.5729];


%3,9
value_2 = 1.0e+07 * [0.0458    2.6306    2.5787    2.5739    2.5730    2.5728    2.5728    2.5728    2.5728    2.5728];

%2,9
%出现错误
value_3 = zeros(1,10);

%5,9.5
value_4 = 1.0e+07 * [0.0458    2.6189    2.6010    2.5752    2.5726    2.5729    2.5729    2.5729    2.5729    2.5729];



%3,9.5
value_5 =1.0e+07 * [0.0458    2.6306    2.5787    2.5739    2.5730    2.5728    2.5728    2.5728    2.5728    2.5728];

%2,9.5
%出现错误
value_6 = zeros(1,10);

%5,10
value_7 =1.0e+07 * [0.0458    2.6189    2.6010    2.5752    2.5726    2.5729    2.5729    2.5729    2.5729    2.5729];


%5,11
value_8 =1.0e+07 * [0.0458    2.6189    2.6010    2.5752    2.5726    2.5729    2.5729    2.5729    2.5729    2.5729];


%5,20
value_9 =1.0e+07 * [0.0458    2.6189    2.6010    2.5752    2.5726    2.5729    2.5729    2.5729    2.5729    2.5729];


%3,20
value_10 =1.0e+07 * [0.0458    2.6306    2.5787    2.5739    2.5730    2.5728    2.5728    2.5728    2.5728    2.5728];


%6,20
value_11 =1.0e+07 * [0.0458    2.6189    2.6010    2.5752    2.5726    2.5729    2.5729    2.5729    2.5729    2.5729];

%3,10
value_12 =1.0e+07 * [0.0458    2.6306    2.5787    2.5739    2.5730    2.5728    2.5728    2.5728    2.5728    2.5728];



% 绘制图形
figure;
hold on
plot(c, value_1, '-o', 'DisplayName', 'Value1:5,9');
plot(c, value_2, '-o', 'DisplayName', 'Value2:3,9');
plot(c, value_3, '-o', 'DisplayName', 'Value3:2,9');
plot(c, value_4, '-o', 'DisplayName', 'Value4:5,9.5');
plot(c, value_5, '-o', 'DisplayName', 'Value5:3,9.5');
plot(c, value_6, '-o', 'DisplayName', 'Value6:2,9.5');
plot(c, value_7, '-o', 'DisplayName', 'Value7:5,10');
plot(c, value_8, '-o', 'DisplayName', 'Value8:5,11');
plot(c, value_9, '-o', 'DisplayName', 'Value9:5,20');
plot(c, value_10, '-o', 'DisplayName', 'Value10:3,20');
plot(c, value_11, '-o', 'DisplayName', 'Value11:6,20');
plot(c, value_12, '-o', 'DisplayName', 'Value12:3,10');
hold off
% 添加标签和标题
xlabel('c');
ylabel('Value');
title('Plot of Value  against c');
legend;
grid on;
