function [users_x,users_y,uav_x,uav_y]=Path_generation_center_gs()
% 
%  clear; 
%  close all; 
%  clc;

rng(3);

% 用户和无人机轨迹生成（改进版）

% 时间槽数量
time_slots = 100;

% 用户数量
num_users_s = 24;  % 跟随高斯-马尔可夫轨迹的用户数量
num_users_l = 0;   % 跟随直线轨迹的用户数量

% 总用户数量
total_users = num_users_s + num_users_l;

% 初始化用户和无人机轨迹矩阵
user_trajectory = zeros(total_users, time_slots, 2);
uav_trajectory = zeros(3, time_slots, 2);

%中心轨迹
[x_gm,y_gm] = x_gm_y_gm();

% 直线轨迹（用于其他用户）
x_l = linspace(0, x_gm(1,time_slots), time_slots);  % x 方向线性增加
y_l = zeros(1, time_slots);          % y 保持为零

% 为用户在中心轨迹周围生成随机偏移
for i = 1:time_slots
    % 在高斯-马尔可夫轨迹周围随机生成用户
    r_s = 7 * rand(1, num_users_s);                % 随机半径
    theta_s = 2 * pi * rand(1, num_users_s);       % 随机角度
    x_rand_s = x_gm(i) + r_s .* cos(theta_s);
    y_rand_s = y_gm(i) + r_s .* sin(theta_s);
    
    % 存储在轨迹矩阵中（高斯-马尔可夫用户）
    user_trajectory(1:num_users_s, i, 1) = x_rand_s;
    user_trajectory(1:num_users_s, i, 2) = y_rand_s;
    
    % 在直线轨迹周围随机生成用户
    r_l = 7 * rand(1, num_users_l);                % 随机半径
    theta_l = 2 * pi * rand(1, num_users_l);       % 随机角度
    x_rand_l = x_l(i) + r_l .* cos(theta_l);
    y_rand_l = y_l(i) + r_l .* sin(theta_l);
    
    % 存储在轨迹矩阵中（直线用户）
    user_trajectory(num_users_s+1:end, i, 1) = x_rand_l;
    user_trajectory(num_users_s+1:end, i, 2) = y_rand_l;
end

% 生成无人机轨迹
% 为简化起见，让无人机使用与 x_l 相同的 x 坐标
uav_trajectory(:, :, 1) = repmat(x_l, 3, 1);

% 无人机1在高斯-马尔可夫路径上方
uav_trajectory(1, :, 2) = 300 *sin(x_l/630 *pi);

% 无人机2沿直线路径
uav_trajectory(2, :, 2) = zeros(1, time_slots);

% 无人机3在高斯-马尔可夫路径下方
uav_trajectory(3, :, 2) = -300 *sin(x_l/630 *pi);

% 通过添加偏移量使轨迹居中
offset = 100;
user_trajectory = user_trajectory + offset;
uav_trajectory = uav_trajectory + offset;
x_gm = x_gm + offset;
y_gm = y_gm + offset;

% 提取用户和无人机的坐标
users_x = user_trajectory(:, :, 1);
users_y = user_trajectory(:, :, 2);
uav_x = uav_trajectory(:, :, 1);
uav_y = uav_trajectory(:, :, 2);


save('myMatrices_center_gs.mat', 'users_x', 'users_y','uav_x','uav_y');

uav_y = uav_y + 350;
users_y = users_y +350;

% hold on
% %绘制用户轨迹
% for i = 1:24
%     plot(users_x(i, :), users_y(i, :), 'b');
% end
% 
% %绘制无人机轨迹
% for j = 1:3
%     plot(uav_x(j, :), uav_y(j, :), 'r', 'LineWidth', 2);
% end
% 
% 
% hold off;
