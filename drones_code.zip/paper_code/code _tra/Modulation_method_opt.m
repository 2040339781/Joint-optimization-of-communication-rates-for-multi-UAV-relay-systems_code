function  [x] = Modulation_method_opt(B,R_l,SNR_m_BS,f,i)        %调制方式优化

%所有变量使用标准单位

%R_i = 1e6;


[M, ~] = size(SNR_m_BS);

%得到C_l
C_l = 2 .^ (R_l ./ (B * log2(1 + SNR_m_BS))); %num_drones x 1

%C_l = min(C_l, 256);

% CVX优化求解
cvx_begin quiet
   
    variable b(M,5) binary
    variable eta  % 优化目标值

    % 求解目标：最小化 -eta
    maximize(sum(b * [2; 4; 16; 64; 256]))
    % 约束条件
    subject to


        sum(b(:, :), 2) == 1;
        b * [2; 4; 16; 64; 256] >= C_l;
         SNR_m_BS >= b * f;
       
cvx_end

b = round(b);

x = b * [2;4; 16; 64; 256];
%x = b * [4; 16; 64; 256];

%检查优化状态
% 检查优化状态
if strcmp(cvx_status, 'Solved') == 0
    % 如果优化失败，显示错误信息
    cvx_status
    SNR_m_BS
    C_l
    error(sprintf('第%d时隙无人机调制方式优化错误', i));
end

