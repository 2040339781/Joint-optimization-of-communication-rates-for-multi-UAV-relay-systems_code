function [optimal_SNR,value,distance_matrix] = value_calculation_N_fun(pow,tra_x,tra_y,acc_u,acc_fm,acc_v,...
    users_x,users_y,h_uav,a_env, b_env,shadow_fading,G_r,G_t,B_uav,n0)

    [num_users,N] = size(users_x);
    [num_drones,~] = size(tra_x);

    distance_matrix = distance_matrix_calculate(users_x,users_y,tra_x,tra_y,num_users, num_drones,N,h_uav);

    pre_distance_matrix = distance_matrix .* acc_u;

    pre_distance_matrix_gim = sum(pre_distance_matrix, 2);

    acc_fm_pre = acc_fm(1:num_users,:,:);
    acc_fm_pre = sum(acc_fm_pre, 2);

    [~ ,acc_gim] = ATG_Channel_Model(pre_distance_matrix_gim, h_uav, acc_fm_pre, a_env, b_env,shadow_fading,G_r,G_t);
    
    acc_gim = repmat(acc_gim, 1, num_drones);
    acc_gim = acc_gim .* acc_u;

    optimal_SNR = value_calculation_N(pow(1:num_users,:,:),acc_gim,acc_v,B_uav , n0);

    value = B_uav * log2(1+optimal_SNR);

end