function [pow,x_0,y_0,eta] = Power_Tra_Opt(pow_0,x_0,y_0,...
    acc_u,D_iBSm, G_BSm,H_cons_uav,...
    users_x,users_y,h_uav,BS_loc,acc_v,P_max,B_uav,n0,area,v_max,dT,drone_mass)

% pow_0                              (num_users+1) x num_drones x N
% x_0                             num_drones x N
% y_0                            num_drones x N
% optimal_acc_u                 num_users x num_drones x N
% D_iBSm                      (num_users+1) x num_drones x N
% G_BSm                       num_drones x 1 x N
% F_BSm                          num_drones x 1 x N
% H_cons_uav                  标量
% C_im                         num_users x num_drones x N
% users_x                         %num_users x N
% users_y                            %num_users x N
% h_uav                       标量
% BS_loc                       1x2
% optimal_acc_v            num_users x num_users x N
% P_max                      标量
% B_uav                   标量
% n0                     标量
% area                   标量
% d_min                     标量
% v_max                    标量
% dT                      标量
% drone_mass             标量

[m,n,N] = size(pow_0);
num_users = m - 1;
num_drones = n;

acc_u_num = zeros(num_users, 1 ,N);   %元素为用户接入的无人机
acc_v_num = zeros(num_users, 1 ,N);     %元素为第几个用户产生干扰
acc_u_num_user = zeros(num_users/num_drones, num_drones ,N);   %元素为无人机的用户序号

for t=1:N
    acc_u_num(:, : ,t) = acc_u(:, : ,t) * (1:num_drones)';      %num_users x 1 x N，用户接入哪个无人机

    [row, col] = find(acc_v(:,:,t));
    acc_v_num(row, 1 ,t) = col;%num_users x 1 x N

    for k = 1:num_drones
        acc_u_num_user(:,k,t) = find(acc_u(:, k, t) == 1);

    end

end

% pow_0_i = pow_0(1:num_users,:,:);
% pow_0_i = sum(pow_0_i, 2);              %num_users x 1 x N
% 
% pow_0_BS = pow_0(num_users + 1,:,:);              %1 x num_drones x N

C_i_l = zeros(num_users , 1 , N);
C1_i_l = zeros(num_users , 1 , N);
C2_i_l = zeros(num_users , 1 , N);
C3_i_l = zeros(num_users , 1 , N);
C4_i_l = zeros(num_users , 1 , N);

C_i = zeros(num_users , 1 , N);
C1_i = zeros(num_users , 1 , N);
C2_i = zeros(num_users , 1 , N);
C3_i = zeros(num_users , 1 , N);

C_BS = zeros(num_drones , 1 , N);
C1_BS = zeros(num_drones , 1 , N);
C2_BS = zeros(num_drones , 1 , N);
C3_BS = zeros(num_drones , 1 , N);


for t = 1:N
    for i = 1:num_users
        j = acc_u_num(i,1,t);  %t时刻用户i接入j无人机
        l = acc_v_num(i,1,t);  %t时刻用户l对用户i产生干扰
        if l
            C_i_l(i,1,t) = (x_0(j,t)-users_x(i,t))^2+(y_0(j,t)-users_y(i,t))^2+h_uav^2+(P_max*D_iBSm(i,j,t)*pow_0(l,j,t))/(n0*B_uav);
            C1_i_l(i,1,t) = log((n0*B_uav)/(P_max*D_iBSm(i,j,t))*C_i_l(i,1,t));
            C2_i_l(i,1,t) = 2*(x_0(j,t)-users_x(i,t))/C_i_l(i,1,t);
            C3_i_l(i,1,t) = 2*(y_0(j,t)-users_y(i,t))/C_i_l(i,1,t);
            C4_i_l(i,1,t) = ((P_max*D_iBSm(i,j,t))/(n0*B_uav))/C_i_l(i,1,t);


        else
            C_i(i,1,t) = (x_0(j,t)-users_x(i,t))^2+(y_0(j,t)-users_y(i,t))^2+h_uav^2;
            C1_i(i,1,t) = log((n0*B_uav)/(P_max*D_iBSm(i,j,t))*C_i(i,1,t));
            C2_i(i,1,t) = 2*(x_0(j,t)-users_x(i,t))/C_i(i,1,t);
            C3_i(i,1,t) = 2*(y_0(j,t)-users_y(i,t))/C_i(i,1,t);
        end

    end

    for k = 1:num_drones
       
            C_BS(k,1,t) = (x_0(k,t)-BS_loc(1,1))^2+(y_0(k,t)-BS_loc(1,2))^2+h_uav^2;
            C1_BS(k,1,t) = log(G_BSm(k,1,t)*C_BS(k,1,t));
            C2_BS(k,1,t) = 2*(x_0(k,t)-BS_loc(1,1))/C_BS(k,1,t);
            C3_BS(k,1,t) = 2*(y_0(k,t)-BS_loc(1,2))/C_BS(k,1,t);

    end
end



%%数量级更改

C_i_l_ord = 1;

C1_i_l = C1_i_l * C_i_l_ord;
C2_i_l = C2_i_l * C_i_l_ord;
C3_i_l = C3_i_l * C_i_l_ord;
C4_i_l = C4_i_l * C_i_l_ord;

C_i_ord = 1;
C1_i = C1_i * C_i_ord;
C2_i = C2_i * C_i_ord;
C3_i = C3_i * C_i_ord;

C_BS_ord = 1;

C1_BS = C1_BS * C_BS_ord;
C2_BS = C2_BS * C_BS_ord;
C3_BS = C3_BS * C_BS_ord;

%%



% CVX优化求解
cvx_begin quiet

variable eta 
variable pow_i(m-1,1,N)
variable pow_BS(1,n,N)


% 求解目标：最大化 eta

maximize(eta)

% 约束条件
subject to

for t= 1:N
    for i = 1:num_users    %用户通信速率约束
        j = acc_u_num(i,1,t);
        l = acc_v_num(i,1,t);
        if l
            C_i_l_ord*eta-C_i_l_ord*log(pow_i(i,1,t))+C1_i_l(i,1,t)+C4_i_l(i,1,t)*(pow_i(l,1,t)-pow_0(l,j,t))<=0;
        else
            C_i_ord*eta-C_i_ord*log(pow_i(i,1,t))+C1_i(i,1,t)<=0;
        end

    end

    for k = 1:num_drones   %无人机通信速率约束
        -C_BS_ord*log(pow_BS(1,k,t))+C1_BS(k,1,t)<=0;

    end
end

for t= 1:N   %无人机功率约束
    for k = 1:num_drones
        sum(pow_i(acc_u_num_user(:,k,t),1,t)) + pow_BS(1,k,t) <=1 ;
    end
end

0 <= pow_i <= 1;     %定义域约束
0 <= pow_BS <= 1;




for k = 1:num_drones    %无人机能量约束
    drone_mass/(2*dT)*(sum((x_0(k, 2:N) - x_0(k, 1:N-1)).^2 + (y_0(k, 2:N) - y_0(k, 1:N-1)).^2))+...
        P_max*dT*(sum(sum(acc_u(:,k,:) .* pow_i, 1), 3) + sum(sum(pow_BS(:,k,:), 1), 3)) <= H_cons_uav;
end

cvx_end

% disp(pow_0(:,:,6));
% disp(pow_i(:,:,6));


if strcmp(cvx_status, 'Solved') == 0
    % 如果优化失败，显示错误信息
    cvx_status
    error('功率轨迹优化错误');
end

pow = acc_u .* pow_i;
pow = [pow;pow_BS];
% tra_x
% tra_y
%eta

end