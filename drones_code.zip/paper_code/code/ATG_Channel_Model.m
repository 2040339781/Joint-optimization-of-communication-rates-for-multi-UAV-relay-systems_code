function [g_im_matrix_dB ,g_im_matrix ]= ATG_Channel_Model(d_im_matrix, h_uav, f_c_matrix, a, b,shadow_fading,G_r,G_t)
    % 将距离从米转换为公里,1e6 用于将频率转为MHz
    d_im_matrix_km = d_im_matrix / 1000;
    f_c_matrix_MHz = f_c_matrix / 1e6;
    
    % 计算仰角矩阵 θ_im
    theta_im_matrix = (180/pi) * asin(h_uav ./ d_im_matrix);

    % 计算LoS和NLoS的概率矩阵
    P_LoS_matrix = 1 ./ (1 + a * exp(-b * (theta_im_matrix - a)));
    P_NLoS_matrix = 1 - P_LoS_matrix;

    % 自由空间路径损耗矩阵 L_D
    L_D_matrix = 32.45 + 20 * log10(d_im_matrix_km) + 20 * log10(f_c_matrix_MHz);



    % 计算LoS和NLoS路径损耗矩阵
    L_LoS_matrix = L_D_matrix ;
    L_NLoS_matrix = L_D_matrix + shadow_fading ;

    % 计算平均路径损耗矩阵
    L_avg_matrix = P_LoS_matrix .* L_LoS_matrix + P_NLoS_matrix .* L_NLoS_matrix;
    g_im_matrix_dB = -L_avg_matrix + G_r + G_t;
    % 计算信道增益矩阵
    g_im_matrix = 10.^(g_im_matrix_dB / 10);

end