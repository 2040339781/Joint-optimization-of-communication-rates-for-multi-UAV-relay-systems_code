function [uMod] = Modulation_method_opt_N(B,R_l,SNR_m_BS_N,f)


[~, M, N] = size(SNR_m_BS_N);


uMod = zeros(M, 1, N);


for i=1:N

    SNR_m_BS = (SNR_m_BS_N(:,:,i))';   %num_drones x 1
    [uMod(:,:,i)] = Modulation_method_opt(B,R_l,SNR_m_BS,f,i);


end





