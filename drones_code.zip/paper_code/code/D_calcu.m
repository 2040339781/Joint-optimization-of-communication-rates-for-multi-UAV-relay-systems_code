function D_iBSm = D_calcu(optimal_acc_fm,P_elev_ang,G_t,G_r,shadow_fading,optimal_acc_u)

[m,n,~]=size(optimal_acc_fm);

optimal_acc_fm_Mhz = optimal_acc_fm /1e6;

optimal_acc_fim_Mhz = optimal_acc_fm_Mhz(1:(m-1),:,:);
optimal_acc_fim_Mhz = sum(optimal_acc_fim_Mhz, 2);  %user x 1 xN
optimal_acc_fBSm_Mhz = optimal_acc_fm_Mhz(m,:,:);  %1 x dron xN

P_elev_ang_im = P_elev_ang(1:(m-1),:,:);
P_elev_ang_im = sum(P_elev_ang_im, 2);  %user x 1 xN
P_elev_ang_BS = P_elev_ang(m,:,:);  %1 x dron xN

D_im_matrix = -32.45 - 20 * log10(optimal_acc_fim_Mhz) - P_elev_ang_im *shadow_fading + G_t + G_r;
D_BSm_matrix = -32.45 - 20 * log10(optimal_acc_fBSm_Mhz) - P_elev_ang_BS *shadow_fading + G_t + G_r;

D_im = 10.^(D_im_matrix / 10) * 1e6;  %user x 1 xN
D_im = repmat(D_im, [1, n, 1]);   %mxnxN
D_im = D_im .* optimal_acc_u;
D_BSm = 10.^(D_BSm_matrix / 10) * 1e6;  %1 x dron xN

D_iBSm = [D_im;D_BSm];




end