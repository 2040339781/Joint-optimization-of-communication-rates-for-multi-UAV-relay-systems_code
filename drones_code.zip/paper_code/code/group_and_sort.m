function [M f]=group_and_sort(I,F,f_c)   %其中I为IxM维信道增益矩阵，F为1xM维无人机下限频率，f_c为载波间隔

% clc;
% close all;
% clear all;
% I= [1 0; 5 0; 3 0; 0 6; 2 0; 7 0; 0 2; 2 0; 0 6;0 6;0 1;0 3];
% F=[3 4];
% f_c=2;

[num_pairs,num_pairs1]=size(I);
% display(num_pairs);
% display(num_pairs1);
% display(I);

M=zeros(num_pairs,num_pairs);
f=zeros(num_pairs,1);
for i = 1:num_pairs1
    % Extract non-zero elements and their indices
    non_zero_elements = I(:, i);

    non_zero_indices = find(non_zero_elements);
    values = non_zero_elements(non_zero_indices);

    result_matrix = [non_zero_indices,values];
    [~, sort_order] = sort(result_matrix(:, 2));

    result_matrix = result_matrix(sort_order, :);
    [num_pairs,~]=size(result_matrix);
    num_pairs=num_pairs/2;

    for j = 1:num_pairs
        M(result_matrix(j,1),result_matrix(2*num_pairs-j+1,1))=1;
        f(result_matrix(j,1),1)=F(1,i)+(j-1)*f_c;
        f(result_matrix(2*num_pairs-j+1,1),1)=F(1,i)+(j-1)*f_c;
    end
    
end