function [distance_matrix] = distance_matrix_calculate(users_x,users_y,optimal_tra_x,optimal_tra_y,num_users, num_drones,N,h_uav)


distance_matrix = zeros(num_users, num_drones, N);
 for t = 1:N
        % 获取第 t 个时隙的用户和无人机位置
        users_x_t = users_x(:, t);  % num_users x 1
        users_y_t = users_y(:, t);  % num_users x 1
        uav_x_t = optimal_tra_x(:, t);      % num_drones x 1
        uav_y_t = optimal_tra_y(:, t);      % num_drones x 1

        % 计算坐标差
        % 使用 MATLAB 的隐式扩展（R2016b 及以上版本）
        delta_x = users_x_t - uav_x_t';  % num_users x num_drones
        delta_y = users_y_t - uav_y_t';  % num_users x num_drones

        % 计算距离矩阵
        distance_matrix(:, :, t) = sqrt(delta_x.^2 + delta_y.^2 + h_uav^2);  % num_users x num_drones
    end