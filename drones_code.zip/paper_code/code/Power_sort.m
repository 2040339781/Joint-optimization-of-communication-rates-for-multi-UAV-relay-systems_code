function C_N = Power_sort(A_N, B_N, D_N)

    % 获取矩阵的尺寸
    [m_plus, n,N] = size(A_N);  
       
    C_N = zeros(m_plus, n,N);

for i = 1:N
    A  = A_N(1:(m_plus-1), :,i);
    B = B_N(:,:,i);
    C = A_N(1:(m_plus-1), :,i);
    D = D_N(:,:,i);
    % 对每一列的元素进行操作
    for j = 1:n
        % 获取B和D的当前列
        B_col = B(:, j);
        D_col = D(:, j);

        % 对B的当前列进行排序并获取排序索引
        [~, B_sort_idx] = sort(B_col);
        % 对D的当前列进行排序并获取排序索引
        [~, D_sort_idx] = sort(D_col);

        % 使用B的排序索引对A的当前列进行重新排列，赋值给C的当前列
        C(D_sort_idx, j) = A(B_sort_idx, j);
    end
    C_N(1:(m_plus-1), :,i) = C;
    C_N(m_plus, :,i) = A_N(m_plus, :,i);
end
end
