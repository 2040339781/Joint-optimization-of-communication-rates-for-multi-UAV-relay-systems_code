function [x]=ILP_algorithm(cost_matrix)

[I,M]=size(cost_matrix);
P=I/M;

%%最大化用户信道增益和
cvx_begin quiet
    variable x(I, M) binary
    maximize( sum(sum( cost_matrix .* x )) )
    subject to

    % 每个用户在每个时隙必须接入一架无人机
        sum(x(:, :), 2) == 1;

    % 每架无人机在每个时隙最多接入 P 个用户
        sum(x(:, :), 1)' == P;

cvx_end

%%最大化最小用户信道增益
% cvx_begin quiet
%     variable x(I, M) binary
%     maximize eta 
%     subject to
%     
%         sum( cost_matrix .* x ,2) >= eta;
%         
%     % 每个用户在每个时隙必须接入一架无人机
%         sum(x(:, :), 2) == 1;
% 
%     % 每架无人机在每个时隙最多接入 P 个用户
%         sum(x(:, :), 1)' == P;
% 
% cvx_end



x = round(x);

% 检查优化状态
if strcmp(cvx_status, 'Solved') == 0
    % 如果优化失败，显示错误信息
    cvx_status
    error('无人机调制方式优化错误'); 
end




% [~, col_indices] = max(x, [], 2);
%
% col_indices;
% i=1;

end