function [channel_gain_matrix_u,channel_gain_matrix,channel_gain_matrix_v,...
   user_frequency] =ILP(channel_gain_matrix,drone_frequency,carrier_spacing)
%输入IxM维信道增益矩阵
%输出信道增益矩阵用户分组u
% 
% clc;
% close all;
% clear all;
% 
% drone_frequency=[3 4 5];
% carrier_spacing=2;
% 
% channel_gain_matrix = rand(4, 2)% 生成一个信道增益矩阵,I是M的整数倍
% % 假设你有一个 I x M 的信道增益矩阵 channel_gain_matrix
%channel_gain_matrix=real(channel_gain_matrix);


[I,M]=size(channel_gain_matrix);

% 计算 m，m 是 I / M
k = I / M;

[xy] =ILP_algorithm (channel_gain_matrix);

% 使用 repmat 复制每一列并 reshape
%channel_gain_matrix = reshape(repmat(channel_gain_matrix, k, 1), I, I);

% cost_matrix = channel_gain_matrix;
% 
% cost_matrix = cost_matrix - min(cost_matrix(:));
% cost_matrix = cost_matrix / max(cost_matrix(:));
%[xy] =KM_algorithm (cost_matrix)
%[xy] =ILP (cost_matrix);

% disp('Maximum Weight Matching:');
% disp(xy);   %匹配结果输出

% SelectedZeros = zeros(I,I);
% for ij=1:I
% SelectedZeros(ij,xy(ij,1))=1;
% end

%disp(SelectedZeros);   %匹配结果输出

% figure;
% imagesc(SelectedZeros);
% colormap(gray); % 使用灰度颜色图
% colorbar;
% axis equal;
% title('36x36 Random Binary Matrix');
% xlabel('Column Index');
% ylabel('Row Index');

% Z=SelectedZeros.*channel_gain_matrix;
% 
% A = zeros(I, M);
% % 对每 n 列进行求和
% for i = 1:M
%    A(:, i) = sum(Z(:, (i-1)*k+1:i*k), 2);
% end
% channel_gain_matrix=A;
% channel_gain_matrix_u = zeros(I, M);
% for i = 1:M
%    channel_gain_matrix_u(:, i) = sum(SelectedZeros(:, (i-1)*k+1:i*k), 2);
% end;

%display(full(channel_gain_matrix));
channel_gain_matrix = channel_gain_matrix .* xy;
%display(full(channel_gain_matrix));
%display(full(xy));

channel_gain_matrix_u = xy;


%display(channel_gain_matrix);
%display(full(channel_gain_matrix));
%display(drone_frequency);
%display(carrier_spacing);

[channel_gain_matrix_v, user_frequency]=group_and_sort(channel_gain_matrix,...
    drone_frequency,carrier_spacing);


%display(channel_gain_matrix_v);
%display(user_frequency);


