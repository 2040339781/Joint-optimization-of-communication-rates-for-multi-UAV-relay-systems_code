function [umod] = modulation_opt(prev_pow,prev_tra_x,prev_tra_y,acc_fm,BS_loc,h_uav , ...
    a_env, b_env,shadow_fading,G_r,G_t,B_uav,R_l,mod_infor,P_max,n0)

[m,num_drones,N] = size(prev_pow);
num_users = m-1;

prev_power_BS = prev_pow(num_users+1,:,:);

    prev_d_BSm_matrix = zeros(1,num_drones, N);
    for t = 1:N
        % 获取第 t 个时隙的无人机位置
        uav_x_t = prev_tra_x(:, t);      % num_drones x 1
        uav_y_t = prev_tra_y(:, t);      % num_drones x 1

        % 计算坐标差
        % 使用 MATLAB 的隐式扩展（R2016b 及以上版本）
        delta_x = uav_x_t - BS_loc(1,1);  % num_drones x 1
        delta_y = uav_y_t - BS_loc(1,2);  % num_drones x 1

        % 计算距离矩阵
        prev_d_BSm_matrix(:, :, t) = (sqrt(delta_x.^2 + delta_y.^2 + h_uav^2))';  % 1 x num_drones
    end

    [~ ,prev_g_BSm_matrix] = ATG_Channel_Model(prev_d_BSm_matrix, h_uav, acc_fm(num_users+1,:,:), a_env, b_env,shadow_fading,G_r,G_t);

    prev_SNR_m_BS_N = (P_max / (n0 * B_uav)) * (prev_g_BSm_matrix .* prev_power_BS);  %1 x num_drones x N

    [umod] = Modulation_method_opt_N(B_uav,R_l,prev_SNR_m_BS_N,mod_infor);  %num_drones x 1 x N
    %umod = prev_umod;