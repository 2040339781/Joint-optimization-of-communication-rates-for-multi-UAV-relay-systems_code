function [optimal_value_pre,C] = value_calculation(prev_optimal_pow,optimal_acc_gm,optimal_acc_v,B_uav , n0)

pow = sum(prev_optimal_pow, 2);
gm = sum(optimal_acc_gm, 2);

A = pow .* gm;
B = optimal_acc_v;
P = B_uav * n0;
% 输入：
% A - m x 1 的向量
% B - m x m 的状态矩阵，每行只有 0 或 1 个 1
% P - 标量
% 输出：
% C - m x 1 的向量

% 获取向量 A 的长度，即 m 的值
m = length(A);

% 初始化 C 为 A 除以 P
C = A / P;

% 找到矩阵 B 中所有等于 1 的元素的位置
[rowIndices, colIndices] = find(B);

% 对于每个等于 1 的位置，更新对应的 C(i)
for k = 1:length(rowIndices)
    i = rowIndices(k);
    j = colIndices(k);
    C(i) = A(i) / (P + A(j));
end

optimal_value_pre = min(C);



end