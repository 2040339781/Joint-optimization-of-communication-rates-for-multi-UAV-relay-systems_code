function [optimal_value_pre,c] = value_calculation_N(prev_optimal_pow_N,optimal_acc_gm_N,optimal_acc_v_N,B_uav , n0)
% prev_optimal_pow_N   num_users x num_drones x N
% optimal_acc_gm_N    num_users x num_drones x N
% optimal_acc_v_N    num_users x num_users x N

[num_users,~,N] = size(prev_optimal_pow_N);
optimal_value_pre_N = zeros(1,N);
c = zeros(num_users,1,N);

for i = 1 : N

prev_optimal_pow = prev_optimal_pow_N (:,:,i);
optimal_acc_gm = optimal_acc_gm_N (:,:,i);
optimal_acc_v =  optimal_acc_v_N (:,:,i);

[optimal_value_pre_N(1,i),c(:,:,i)] = value_calculation(prev_optimal_pow,optimal_acc_gm,optimal_acc_v,B_uav , n0);

end

optimal_value_pre = min(optimal_value_pre_N);
