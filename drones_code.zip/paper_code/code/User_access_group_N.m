function [channel_gain_matrix_u_N,g_im_matrix_N, channel_gain_matrix_v_N,user_frequency_expanded_matrix_N]= User_access_group_N...
(d_im_matrix_N, drone_frequency, h_uav, a, b,shadow_fading,carrier_spacing,G_r,G_t)

% channel_gain_matrix_u_N：用户接入矩阵
% g_im_matrix_N：信道增益矩阵
% channel_gain_matrix_v_N：信道增益参数

[I, M, N] = size(d_im_matrix_N);
channel_gain_matrix_u_N=zeros(I, M, N);
g_im_matrix_N=zeros(I, M, N);
channel_gain_matrix_v_N=zeros(I, I, N);
user_frequency_expanded_matrix_N=zeros(I + 1, M, N);

for i=1:N
    d_im_matrix= d_im_matrix_N(:,:,i);
    [channel_gain_matrix_u,g_im_matrix, channel_gain_matrix_v,user_frequency_expanded_matrix] = User_access_group...
        (d_im_matrix, drone_frequency, h_uav, a, b,shadow_fading,carrier_spacing,G_r,G_t);

    user_frequency_expanded_matrix_N(:,:,i)=user_frequency_expanded_matrix;
    channel_gain_matrix_u_N(:,:,i)=channel_gain_matrix_u;
    g_im_matrix_N(:,:,i)=g_im_matrix;
    channel_gain_matrix_v_N(:,:,i)=channel_gain_matrix_v;

end
