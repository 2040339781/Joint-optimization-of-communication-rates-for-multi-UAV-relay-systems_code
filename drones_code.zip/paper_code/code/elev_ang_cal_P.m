function [P_elev_ang] = elev_ang_cal_P(distance_matrix,d_BSm_matrix,optimal_acc_u,a, b,h_uav)


    theta_im_matrix = (180/pi) * asin(h_uav ./ distance_matrix);
    theta_BSm_matrix = (180/pi) * asin(h_uav ./ d_BSm_matrix);

    % 计算LoS和NLoS的概率矩阵
    P_LoS_matrix_im = 1 ./ (1 + a * exp(-b * (theta_im_matrix - a)));
    P_NLoS_matrix_im = 1 - P_LoS_matrix_im;

    % 计算LoS和NLoS的概率矩阵
    P_LoS_matrix_BSm = 1 ./ (1 + a * exp(-b * (theta_BSm_matrix - a)));
    P_NLoS_matrix_BSm = 1 - P_LoS_matrix_BSm;

    P_NLoS_matrix_im = P_NLoS_matrix_im .* optimal_acc_u;

    P_elev_ang = [P_NLoS_matrix_im;P_NLoS_matrix_BSm];