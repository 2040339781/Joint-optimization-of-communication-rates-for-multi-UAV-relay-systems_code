function [B]=initial_access(m,n,N)


% 参数设置
k = m / n;  % 设置每列有多少个元素为1


% 初始化矩阵
A = zeros(m, n);

% 生成随机排列的行索引
row_indices = randperm(m);

% 将行索引分成 n 组，每组有 k 个索引
for j = 1:n
    % 计算当前组的起始和结束索引
    idx_start = (j - 1) * k + 1;
    idx_end = j * k;
    
    % 获取当前列对应的行索引
    rows = row_indices(idx_start:idx_end);
    
    % 将矩阵 A 中对应的位置设置为 1
    A(rows, j) = 1;
end

% 显示结果
%disp(A);
B = repmat(A, [1, 1, N]);

end