function [channel_gain_matrix_u,g_im_matrix, channel_gain_matrix_v,user_frequency_matrix]= User_access_group...
(d_im_matrix, drone_frequency, h_uav, a, b,shadow_fading,carrier_spacing,G_r,G_t)

[I,M]=size(d_im_matrix);
f_c_expanded_matrix = repmat(drone_frequency, I, 1);

[g_im_matrix_dB ,~] = ATG_Channel_Model(d_im_matrix, h_uav,...
    f_c_expanded_matrix, a, b,shadow_fading,G_r,G_t);

%display(f_c_expanded_matrix);

[channel_gain_matrix_u,~,channel_gain_matrix_v,...
    user_frequency] = ILP(g_im_matrix_dB,drone_frequency,carrier_spacing);

user_frequency_expanded_matrix = repmat(user_frequency, 1, M);

[~,g_im_matrix ] = ATG_Channel_Model(d_im_matrix, h_uav,...
    user_frequency_expanded_matrix, a, b,shadow_fading,G_r,G_t);

%display(user_frequency_expanded_matrix);
user_frequency_expanded_matrix = user_frequency_expanded_matrix .* channel_gain_matrix_u;

user_frequency_matrix = zeros(I + 1,M);
user_frequency_matrix(1 :I,:) = user_frequency_expanded_matrix;
drone_frequency_matrix = drone_frequency +carrier_spacing * (I/M) * 0.5;
user_frequency_matrix(I+1,:) = drone_frequency_matrix;

% size(user_frequency_expanded_matrix)
% size(drone_frequency)
% user_frequency_expanded_matrix = [user_frequency_expanded_matrix; drone_frequency +carrier_spacing * (I/M) * 0.5];
g_im_matrix = g_im_matrix.*channel_gain_matrix_u;


end