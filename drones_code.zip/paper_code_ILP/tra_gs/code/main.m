clear; 
close all; 
clc;



 value_1 = main_test(50000,9.5)
 value_2 = main_test(50000,8.5)
 value_3 = main_test(16000,9.5)
% value_1 = main_test(50000,9)
% value_2 = main_test(50000,10)
% value_3 = main_test(50000,13)
% value_4 = main_test(50000,15)
% value_5 = main_test(50000,17)
% value_6 = main_test(50000,20)
%  
% value_7 = main_test(50000,9.5)
% value_8 = main_test(30000,9.5)
% value_9 = main_test(20000,9.5)




c =

     1


value =

   2.3092e+04


value_total_user =

   1.0e+10 *

    4.2217    4.1588    4.3492


value_total_uav =

   1.0e+09 *

    6.5865    6.6877    6.7889


c =

     2


ans =

   5.8794e+06


value =

   5.9024e+06


value_total_user =

   1.0e+10 *

    3.7105    3.7848    3.8545


value_total_uav =

   1.0e+09 *

    6.2630    6.4223    6.5252


c =

     3


ans =

  -7.0642e+04


value =

   5.8318e+06


value_total_user =

   1.0e+10 *

    3.6947    3.7701    3.7961


value_total_uav =

   1.0e+09 *

    6.2730    6.4315    6.5004


c =

     4


ans =

   5.8102e+04


value =

   5.8899e+06


value_total_user =

   1.0e+10 *

    3.6969    3.7667    3.7817


value_total_uav =

   1.0e+09 *

    6.3090    6.4497    6.4759


c =

     5


ans =

  -1.1935e+05


value =

   5.7706e+06


value_total_user =

   1.0e+10 *

    3.6981    3.7680    3.7644


value_total_uav =

   1.0e+09 *

    6.3301    6.4387    6.4236


c =

     6


ans =

  -2.5439e+04


value =

   5.7451e+06


value_total_user =

   1.0e+10 *

    3.6872    3.7615    3.7912


value_total_uav =

   1.0e+09 *

    6.2593    6.4393    6.4652


c =

     7


ans =

  -3.5344e+04


value =

   5.7098e+06


value_total_user =

   1.0e+10 *

    3.6846    3.7780    3.7696


value_total_uav =

   1.0e+09 *

    6.3022    6.4462    6.4480


c =

     8


ans =

   3.9557e+04


value =

   5.7493e+06


value_total_user =

   1.0e+10 *

    3.6993    3.7620    3.7669


value_total_uav =

   1.0e+09 *

    6.2901    6.5101    6.4587


c =

     9


ans =

  -1.0582e+04


value =

   5.7387e+06


value_total_user =

   1.0e+10 *

    3.6931    3.7705    3.7669


value_total_uav =

   1.0e+09 *

    6.2975    6.5001    6.4784


c =

    10


ans =

   4.2519e+04


value =

   5.7813e+06


value_total_user =

   1.0e+10 *

    3.6936    3.7655    3.7702


value_total_uav =

   1.0e+09 *

    6.3293    6.4957    6.4724


c =

    11


ans =

  -4.1556e+04


value =

   5.7397e+06


value_total_user =

   1.0e+10 *

    3.6901    3.7666    3.7615


value_total_uav =

   1.0e+09 *

    6.3055    6.4917    6.4628

Elapsed time is 2776.362244 seconds.

value_1 =

   1.0e+06 *

    0.0231    5.9024    5.8318    5.8899    5.7706    5.7451    5.7098    5.7493    5.7387    5.7813    5.7397


c =

     1


value =

   2.3092e+04


value_total_user =

   1.0e+10 *

    4.2217    4.1588    4.3492


value_total_uav =

   1.0e+09 *

    6.5865    6.6877    6.7889


c =

     2


ans =

   5.6010e+06


value =

   5.6240e+06


value_total_user =

   1.0e+10 *

    3.6799    3.7691    3.8670


value_total_uav =

   1.0e+09 *

    6.2964    6.4469    6.5171


c =

     3


ans =

   3.9401e+05


value =

   6.0181e+06


value_total_user =

   1.0e+10 *

    3.6599    3.7474    3.7683


value_total_uav =

   1.0e+09 *

    6.3412    6.4156    6.4599


c =

     4


ans =

   6.7033e+05


value =

   6.6884e+06


value_total_user =

   1.0e+10 *

    3.6580    3.7467    3.7614


value_total_uav =

   1.0e+09 *

    6.3520    6.4414    6.4223


c =

     5


ans =

  -4.5728e+05


value =

   6.2311e+06


value_total_user =

   1.0e+10 *

    3.6579    3.7467    3.7504


value_total_uav =

   1.0e+09 *

    6.3415    6.4670    6.4701


c =

     6


ans =

  -4.2345e+05


value =

   5.8077e+06


value_total_user =

   1.0e+10 *

    3.6598    3.7380    3.7686


value_total_uav =

   1.0e+09 *

    6.3459    6.4221    6.4579


c =

     7


ans =

   9.4887e+04


value =

   5.9025e+06


value_total_user =

   1.0e+10 *

    3.6567    3.7441    3.7632


value_total_uav =

   1.0e+09 *

    6.3230    6.4414    6.4462


c =

     8


ans =

   3.7093e+04


value =

   5.9396e+06


value_total_user =

   1.0e+10 *

    3.6588    3.7443    3.7519


value_total_uav =

   1.0e+09 *

    6.3305    6.4209    6.4485


c =

     9


ans =

   5.8979e+05


value =

   6.5294e+06


value_total_user =

   1.0e+10 *

    3.6551    3.7449    3.7580


value_total_uav =

   1.0e+09 *

    6.3303    6.4372    6.4453


c =

    10


ans =

  -7.6295e+05


value =

   5.7665e+06


value_total_user =

   1.0e+10 *

    3.6483    3.7508    3.7577


value_total_uav =

   1.0e+09 *

    6.2911    6.4638    6.4632


c =

    11

41      catch





