clear;
close all;
clc;


c=1:11;


%%5,9.5
value_1 = 1.0e+07 *[0.5309    4.6931    4.7902    5.4387    5.4833    5.2771    5.6486    5.3753    5.6972    5.2576    5.6458];

%%5,8.5
value_2 = 1.0e+07 *[0.5309    4.5526    5.2649    5.4017    5.4603    5.4588    5.4604    5.4586    5.4606    5.4584    5.4608];

%%1.6,9.5
value_3 = 1.0e+07 *[0.5309    4.5373    5.2646    5.3833    5.4404    5.4405    5.4404    5.4406    5.4404    5.4406    5.4403];



% 绘制图形
figure;
hold on

%plot(c, value_1, '-o', 'DisplayName', 'Value1:5,9.5');
plot(c, value_2, '-o', 'DisplayName', 'Value2:5,8.5');
plot(c, value_3, '-o', 'DisplayName', 'Value3:1.6,9.5');



hold off
% 添加标签和标题
xlabel('c');
ylabel('Value');
title('Plot of Value  against c');
legend;
grid on;
