clear; 
close all; 
clc;




%value_1 = main_test(50000,8.5)%
%value_2 = main_test(50000,9.5)%
value_3 = main_test(16000,9.5)%

% value_1 = main_test(16000,8.5)%不能用
% 
% 
% value_2 = main_test(50000,8.5)
% value_3 = main_test(40000,9.5)
% value_4 = main_test(40000,8.5)
% value_5 = main_test(30000,9.5)
% value_6 = main_test(30000,8.5)
% value_7 = main_test(20000,9.5)
% value_8 = main_test(20000,8.5)
% 
% 
% value_2 = main_test(50000,10)
% value_3 = main_test(50000,13)
% value_4 = main_test(50000,15)
% value_5 = main_test(50000,17)
% value_6 = main_test(50000,20)
%  
% value_7 = main_test(50000,9.5)
% value_8 = main_test(30000,9.5)
% value_9 = main_test(20000,9.5)








