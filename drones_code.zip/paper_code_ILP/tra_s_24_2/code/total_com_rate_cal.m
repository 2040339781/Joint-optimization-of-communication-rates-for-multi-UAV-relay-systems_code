function [value_total_user,value_total_uav,value_total_uav_] = total_com_rate_cal(pow,tra_x,tra_y,acc_u,acc_fm,acc_v,...
    users_x,users_y,BS_loc,h_uav,a_env, b_env,shadow_fading,G_r,G_t,B_uav,n0)

    [num_users,N] = size(users_x);
    [num_drones,~] = size(tra_x);

    distance_matrix = distance_matrix_calculate(users_x,users_y,tra_x,tra_y,num_users, num_drones,N,h_uav);

    pre_distance_matrix = distance_matrix .* acc_u;

    pre_distance_matrix_gim = sum(pre_distance_matrix, 2);

    acc_fm_pre = acc_fm(1:num_users,:,:);
    acc_fm_pre = sum(acc_fm_pre, 2);

    [~ ,acc_gim] = ATG_Channel_Model(pre_distance_matrix_gim, h_uav, acc_fm_pre, a_env, b_env,shadow_fading,G_r,G_t);
    
    acc_gim = repmat(acc_gim, 1, num_drones);
    acc_gim = acc_gim .* acc_u;

    [~,total_SNR] = value_calculation_N(pow(1:num_users,:,:),acc_gim,acc_v,B_uav , n0);

    value_total_user_i = B_uav * log2(1+total_SNR);   %num_users x 1 x N
    value_total_user_i = value_total_user_i .* acc_u;    %num_users x num_drones x N

    value_total_user_ = sum(value_total_user_i,1); %1 x num_drones x N
    value_total_user = sum(value_total_user_,3); %1 x num_drones
    
    
    power_BS = pow(num_users+1,:,:);
    d_BSm_matrix = zeros(1,num_drones, N);
    for t = 1:N
        % 获取第 t 个时隙的无人机位置
        uav_x_t = tra_x(:, t);      % num_drones x 1
        uav_y_t = tra_y(:, t);      % num_drones x 1

        % 计算坐标差
        % 使用 MATLAB 的隐式扩展（R2016b 及以上版本）
        delta_x = uav_x_t - BS_loc(1,1);  % num_drones x 1
        delta_y = uav_y_t - BS_loc(1,2);  % num_drones x 1

        % 计算距离矩阵
        d_BSm_matrix(:, :, t) = (sqrt(delta_x.^2 + delta_y.^2 + h_uav^2))';  % 1 x num_drones
    end

    [~ ,g_BSm_matrix] = ATG_Channel_Model(d_BSm_matrix, h_uav, acc_fm(num_users+1,:,:), a_env, b_env,shadow_fading,G_r,G_t);
    
    value_total_uav_ = B_uav * log2(1+(power_BS.*g_BSm_matrix)/(n0 *B_uav));   %1 x num_drones x N
    
    value_total_uav = sum(value_total_uav_,3); %1 x num_drones
   
end