clear;
close all;
clc;


c=1:11;

%5,9.5
value_1 = 1.0e+07 *[0.5309,5.2989,5.5499,5.5790,5.5796,5.5802,5.5794,5.5802,5.5794,5.5802,5.5794];

%5,8.5
value_2 = 1.0e+07 *[0.5309,4.8434,5.5053,5.5293,5.5279,5.5276,5.5277,5.5267,5.5276,5.5256,5.5277];

%1.6，9.5
value_3 = 1.0e+07 *[0.5309    4.8464    5.4298    5.5075    5.5094    5.5092    5.5088    5.5087    5.5084    5.5086    5.5080];




% 绘制图形
figure;
hold on

plot(c, value_1, '-o', 'DisplayName', 'Value1:5,9.5');
plot(c, value_2, '-o', 'DisplayName', 'Value2:5,8.5');
plot(c, value_3, '-o', 'DisplayName', 'Value3:1.6,9.5');



hold off
% 添加标签和标题
xlabel('c');
ylabel('Value');
title('Plot of Value  against c');
legend;
grid on;




