clear; 
close all; 
clc;

value_3 = main_test(19000,9.5)
value_1 = main_test(50000,9.5)
value_2 = main_test(50000,8.5)
value_3 = main_test(16000,9.5)









