
clear; 
close all; 
clc;

c=1:11;



%5,9.5
value_1 =1.0e+07 *[0.5309    4.8589    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587];

%5,8.5
value_2 =1.0e+07 *[0.5309    4.8589    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587    4.8587];

%1.6,9.5

%无可行解


% 绘制图形
figure;
hold on

plot(c, value_1, '-o', 'DisplayName', 'Value1:5,9.5');
plot(c, value_2, '-o', 'DisplayName', 'Value2:5,8.5');
%plot(c, value_3, '-o', 'DisplayName', 'Value3:1.6,9.5');

hold off
% 添加标签和标题
xlabel('c');
ylabel('Value');
title('Plot of Value  against c');
legend;
grid on;


