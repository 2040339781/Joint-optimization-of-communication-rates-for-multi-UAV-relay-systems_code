function [value_main] = main_test(E_max,v_max)
% clear; 
% close all; 
% clc;

tic;

% 设置随机数生成器种子（为了结果可重复）:全局

rng(3);   %%非常重要！！！决定结果可重复性，即使你没有使用随机函数！！！

%cvx_clear;
%cvx_solver Mosek_5;  % 指定使用MOSEK求解器，可以在命令行中运行
%cvx_save_prefs      % 保存当前的 CVX 偏好设置，全局
%cvx_quiet true    %抑制输出信息

%% 参数设置
BS_loc = [-500,-500];       % 基站位置
area = 1000;                  % 区域：1000x1000
N = 100;                      % 时间间隔数量N     N=T/δ_T :100
T = 100;                      % 辅助通信时长T       50~500s:100
dT = 1;                       % 时间间隔持续时间为δ_T  0.5~5s:1s
num_users = 24;               % 用户数量I    24
num_drones = 3;               % 无人机数量M     3
drone_mass = 3;               % 无人机质量W_m    1~20kg
P0 = 30;                      % 螺旋桨的固定功率P_0     10W~100W
k = 0.2;                      % 常数k                     0~0.5
rho = 1;                      % 空气密度ρ             1~1.3kg/m^3
A = 0.05;                     % 螺旋桨的转盘面A           0.05~0.5m^2
f_m = [5729 5769 5809] * 1e6;       % 无人机频率底频f_m                    5.8 GHz ISM 频段: 5.725~5.850 GHz :125MHz,分15份
B_uav = 6 * 1e6;                    % 通信带宽B
f_c = 8 * 1e6;                      % 频率间隔f_c                       2~10MHz
h_uav = 100;                  % 无人机轨道高度h_m^uav              50~500m
a_env = 9.61;                 % 环境参数a,b                    a=9.61,b=0.16
b_env = 0.16; 
shadow_fading = 10;            % 阴影衰落δ                        4~8dB
n0 = 1e-21;                    % 噪声功率谱密度n_0,单位W/Hz          -180dBm/Hz              -190~-120dBm/Hz
G_r = 4;                      % 接收器天线增益G_r^user                    0~5dBi
G_t = 10;                     % 发射器天线增益G_t^uaν               3~10dBi
uav_users = 8;                % 无人机接入用户α                   8
co_channel_intf = 1;          % 同频干扰最多γ-1                    1
BER_q = 1e-6;                 % 阈值要求BER_q：                           10^(-6)

P_max = 5;                    % 最大发射功率P_max^m                      0.1~5W
%E_max = 6000;                % 最大能量存储容量E_max^m        50000~1000000J
%v_max = 9;                   % 最大速度v_m^max                     5~30m/s
R_l = 1 * (num_users/num_drones) * 1e6;               % 指定阈值R_l                             0.5~10Mbps×8
c_max = 10;                    % 最大迭代次数
mu_pow = 1e-6;             % 功率轨迹函数最优值精度
mu_tra = 1e-6;          % 功率轨迹函数最优值精度,根据数据数值最后设置 
mu =  1 ;                    % 主函数最优值精度
mu_value_max=1e4 ;       % 功率轨迹函数最优值精度,根据数据数值最后设置  
c_pow_tra_max = 100;  %功率轨迹子问题最大迭代次数

%%参数计算
f0 = 0;
f1 = 2 * (erfcinv(2 * BER_q))^2;
f2 = 10 * (erfcinv((8/3) * BER_q))^2;
f3 = 42 * (erfcinv((24/7) * BER_q))^2;
f4 = 170 * (erfcinv((64/15) * BER_q))^2;
mod_infor = [f0;f1;f2;f3;f4];


H_cons_uav = E_max - (P0 + (1 + k) * (drone_mass^(3/2)) / sqrt(2 * rho * A))*T ;

%% 初始化状态

c = 1              %初始化迭代次数

% 用户和无人机的轨迹由高斯-马尔科夫模型模拟给出

[users_x,users_y,uav_x,uav_y]=Path_generation_s();        %本文轨迹，手动设置

%[users_x,users_y,uav_x,uav_y]=Path_generation_gs();    %基于高斯马尔可夫模型的用户轨迹，无中心轨迹

%[users_x,users_y,uav_x,uav_y]=Path_generation_center_gs();

%[users_x,users_y,uav_x,uav_y]=User_trajectory_generation(num_users,N);
%[users_x,users_y,uav_x,uav_y]=User_trajectory_generation_improve();
% size(users_x)
% size(uav_x)


% 功率设置为全(num_drones / (num_users + num_drones))
power_N = (num_drones / (num_users + num_drones)) * ones(num_users + 1, num_drones, N); 


% 初始化无人机调制方式

umod = 2 * ones(num_drones, 1, N);   %初始化无人机调制方式为二阶

distance_matrix = distance_matrix_calculate(users_x,users_y,uav_x,uav_y,num_users, num_drones,N,h_uav);

%[acc_u,acc_fm,acc_v] = init_acc_u_fm_v_improve(N);  %初始化用户接入和干扰情况

[acc_u,~, acc_v,acc_fm] = User_access_group_N...
         (distance_matrix, f_m, h_uav, a_env, b_env,shadow_fading,f_c,G_r,G_t); %num_users x num_drones x N
[acc_u,acc_fm,acc_v] = init_acc_u_fm_v_improve(N);  %初始化用户接入和干扰情况

power_N(1:num_users, :,:) = power_N(1:num_users, :,:) .* acc_u;  %初始化用户功率

[SNR,value,~] = value_calculation_N_fun(power_N * P_max,uav_x,uav_y,acc_u,acc_fm,acc_v,...
    users_x,users_y,h_uav,a_env, b_env,shadow_fading,G_r,G_t,B_uav,n0);

value  %初始最小用户通信速率
value_main =value;

data_acc_u = zeros(num_users,num_drones,N,c_max+1);         % 初始化前一次迭代的用户接入,num_users x num_drones x N
data_acc_v = zeros(num_users,num_users,N,c_max+1);         % 初始化前一次迭代的用户接入后干扰情况矩阵,num_users x num_users x N
data_acc_fm = zeros(num_users+1,num_drones,N,c_max+1);     %初始化前一次迭代的频率情况矩阵,(num_users + 1) x num_drones x N
data_umod = zeros(num_drones,1,N,c_max+1);         % 初始化前一次迭代的调制方式,num_drones x 1 x N
data_power_N = zeros(num_users+1,num_drones,N,c_max+1);        % 初始化前一次迭代的功率,(num_users + 1) x num_drones x N
data_uav_x = zeros(num_drones,N,c_max+1);        % 初始化前一次迭代的无人机轨迹横坐标，num_drones x N
data_uav_y = zeros(num_drones,N,c_max+1);       % 初始化前一次迭代的无人机轨迹纵坐标，num_drones x N
data_distance_matrix = zeros(num_users,num_drones,N,c_max+1);
data_value = zeros(1,c_max+1);        % 初始化前一次迭代功率轨迹优化后的最优值,标量
data_SNR = zeros(1,c_max+1);           % 初始化前一次迭代功率轨迹优化后信噪比的最优值,标量


prev_acc_u = acc_u;         % 初始化前一次迭代的用户接入,num_users x num_drones x N
prev_acc_v = acc_v;         % 初始化前一次迭代的用户接入后干扰情况矩阵,num_users x num_users x N
prev_acc_fm = acc_fm;     %初始化前一次迭代的频率情况矩阵,(num_users + 1) x num_drones x N
prev_umod = umod;         % 初始化前一次迭代的调制方式,num_drones x 1 x N
prev_pow =  power_N;        % 初始化前一次迭代的功率,(num_users + 1) x num_drones x N
prev_tra_x =  uav_x;        % 初始化前一次迭代的无人机轨迹横坐标，num_drones x N
prev_tra_y =  uav_y;       % 初始化前一次迭代的无人机轨迹纵坐标，num_drones x N
prev_distance_matrix = distance_matrix;
prev_value = value;        % 初始化前一次迭代功率轨迹优化后的最优值,标量
prev_SNR = SNR;           % 初始化前一次迭代功率轨迹优化后信噪比的最优值,标量


data_acc_u(:,:,:,c) = prev_acc_u;
data_acc_v(:,:,:,c) = prev_acc_v;
data_acc_fm(:,:,:,c) = prev_acc_fm;
data_umod(:,:,:,c) = prev_umod;
data_power_N(:,:,:,c) = prev_pow;
data_uav_x(:,:,c) = prev_tra_x;
data_uav_y(:,:,c) = prev_tra_y;
data_distance_matrix(:,:,:,c) = prev_distance_matrix;
data_value(1,c) = prev_value;
data_SNR(1,c) = prev_SNR;


%%迭代优化目标函数
while  (c <= c_max)%|| (opt_dev > mu)
    
    c = c +1


    %% 用户接入分组优化，只和用户无人机间距离有关系

     [acc_u,~, acc_v,acc_fm] = User_access_group_N...
         (prev_distance_matrix, f_m, h_uav, a_env, b_env,shadow_fading,f_c,G_r,G_t); %num_users x num_drones x N
    % acc_u = prev_acc_u;
    % acc_v = prev_acc_v;
    % acc_fm = prev_acc_fm;

    %按用户分组后的信道增益重新分配功率
    prev_pow = Power_sort(prev_pow, prev_distance_matrix .* prev_acc_u, prev_distance_matrix .* acc_u);


    %% 无人机调制方式优化，和无人机基站信噪比有关系
    prev_power_BS = prev_pow(num_users+1,:,:);

    prev_d_BSm_matrix = zeros(1,num_drones, N);
    for t = 1:N
        % 获取第 t 个时隙的无人机位置
        uav_x_t = prev_tra_x(:, t);      % num_drones x 1
        uav_y_t = prev_tra_y(:, t);      % num_drones x 1

        % 计算坐标差
        % 使用 MATLAB 的隐式扩展（R2016b 及以上版本）
        delta_x = uav_x_t - BS_loc(1,1);  % num_drones x 1
        delta_y = uav_y_t - BS_loc(1,2);  % num_drones x 1

        % 计算距离矩阵
        prev_d_BSm_matrix(:, :, t) = (sqrt(delta_x.^2 + delta_y.^2 + h_uav^2))';  % 1 x num_drones
    end

    [~ ,prev_g_BSm_matrix] = ATG_Channel_Model(prev_d_BSm_matrix, h_uav, acc_fm(num_users+1,:,:), a_env, b_env,shadow_fading,G_r,G_t);

    prev_SNR_m_BS_N = (P_max / (n0 * B_uav)) * (prev_g_BSm_matrix .* prev_power_BS);  %1 x num_drones x N

    %[umod] = Modulation_method_opt_N(B_uav,R_l,prev_SNR_m_BS_N,mod_infor);  %num_drones x 1 x N
    umod = prev_umod; 



    %% 无人机功率轨迹优化子问题

    %常数计算
    distance_matrix_P = prev_distance_matrix .* acc_u;
    distance_matrix_P = sum(distance_matrix_P, 2);
    P_elev_ang = elev_ang_cal_P(distance_matrix_P,prev_d_BSm_matrix,acc_u,a_env, b_env,h_uav);%(num_users+1) x num_drones x N,计算俯仰角
    D_iBSm = D_calcu(acc_fm,P_elev_ang,G_t,G_r,shadow_fading,acc_u);%(num_users+1) x num_drones x N

    G_BSm = ((n0 * B_uav)/P_max) * (2^(R_l /B_uav)-1)/D_iBSm(num_users+1,:,:);    % 1 x num_drones x N，不考虑无人机调制阶数影响
    %umod_GBSm = permute(umod, [2, 1, 3]);  % 将 nx1xN 转置为 1xnxN
    %G_BSm = ((n0 * B_uav)/P_max) .* (2.^(R_l ./(B_uav*umod_GBSm))-1)./D_iBSm(num_users+1,:,:);    % 1 x num_drones x N，考虑无人机调制阶数影响
    G_BSm = permute(G_BSm, [2, 1, 3]);  % 交换第一个和第二个维度,num_drones x 1 x N

    [pow,tra_x,tra_y] = Power_trajectory_optimization(prev_pow,prev_tra_x,prev_tra_y,...
            acc_u,acc_v,acc_fm,D_iBSm, G_BSm,H_cons_uav,...
            users_x,users_y,h_uav,BS_loc,P_max,B_uav,n0,area,v_max,dT,drone_mass,mu_tra,mu_pow,...
            a_env, b_env,shadow_fading,G_r,G_t,mu_value_max,c_pow_tra_max);

    [SNR,value,distance_matrix] = value_calculation_N_fun(pow * P_max,tra_x,tra_y,acc_u,acc_fm,acc_v,...
    users_x,users_y,h_uav,a_env, b_env,shadow_fading,G_r,G_t,B_uav,n0);  %计算实际值


    %%更新并保存最优解
    opt_dev = abs(value - prev_value);   %前后目标最优解变化值

    value - prev_value
    value
    value_main = [value_main,value];

    prev_acc_u = acc_u;                                    %mxnxN
    prev_acc_v = acc_v;                                    %mxmxN
    prev_acc_fm = acc_fm;                                  %(m+1)xnxN
    prev_umod = umod;                                      %nx1xN
    prev_pow =  pow;                                       %(m+1)xnxN
    prev_tra_x =  tra_x;                                   %nxN
    prev_tra_y =  tra_y;                                   %nxN
    prev_distance_matrix = distance_matrix;                %mxnxN
    prev_value = value;                                    %标量
    prev_SNR = SNR;                                        %标量

    data_acc_u(:,:,:,c) = prev_acc_u;
    data_acc_v(:,:,:,c) = prev_acc_v;
    data_acc_fm(:,:,:,c) = prev_acc_fm;
    data_umod(:,:,:,c) = prev_umod;
    data_power_N(:,:,:,c) = prev_pow;
    data_uav_x(:,:,c) = prev_tra_x;
    data_uav_y(:,:,c) = prev_tra_y;
    data_distance_matrix(:,:,:,c) = prev_distance_matrix;
    data_value(1,c) = prev_value;
    data_SNR(1,c) = prev_SNR;


    if opt_dev <= mu
        break;
    end
end

toc




