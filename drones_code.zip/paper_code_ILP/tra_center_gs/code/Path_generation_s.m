function [users_x,users_y,uav_x,uav_y]=Path_generation_s()


% 时隙数量
time_slots = 100;
num_users_s = 16;  % S形轨迹的用户数量
num_users_l = 8;   % 直线轨迹的用户数量

% 定义用户总数
total_users = num_users_s + num_users_l;

% 初始化用户轨迹矩阵，大小为：用户数量 × 时隙数量 × 2 (x, y 坐标)
user_trajectory = zeros(24, time_slots, 2);
uav_trajectory = zeros(3, time_slots, 2);


% S形轨迹的参数
A = 800;  % 控制x方向的增量
B = 300;   % 控制S形的振幅
C = 2 * pi / 100;  % 控制S形的周期

% 生成S形轨迹
t = linspace(0, time_slots, time_slots);
x_s = A * t / time_slots;
y_s = B * sin(C * t);

% 直线轨迹（用于8个用户的直线轨迹）
x_l = A * t / time_slots;  % 同样的x方向变化
y_l = zeros(1, time_slots);  % 直线轨迹y值保持0

% 遍历每个时隙，生成随机分布的用户
for i = 1:time_slots
    % 随机生成围绕S形轨迹的用户
    r_s = 6 * rand(1, num_users_s);  % 随机半径
    theta_s = 2 * pi * rand(1, num_users_s);  % 随机角度
    x_rand_s = x_s(i) + r_s .* cos(theta_s);
    y_rand_s = y_s(i) + r_s .* sin(theta_s);
    
    % 存入矩阵 (S形轨迹部分)
    user_trajectory(1:num_users_s, i, 1) = x_rand_s;  % x坐标
    user_trajectory(1:num_users_s, i, 2) = y_rand_s;  % y坐标
    
    % 随机生成围绕直线轨迹的用户
    r_l = 2 * rand(1, num_users_l);  % 随机半径
    theta_l = 2 * pi * rand(1, num_users_l);  % 随机角度
    x_rand_l = x_l(i) + r_l .* cos(theta_l);
    y_rand_l = y_l(i) + r_l .* sin(theta_l);
    
    % 存入矩阵 (直线轨迹部分)
    user_trajectory(num_users_s+1:end, i, 1) = x_rand_l;  % x坐标
    user_trajectory(num_users_s+1:end, i, 2) = y_rand_l;  % y坐标
end

% 打印矩阵大小，确认生成的轨迹矩阵
%disp(size(user_trajectory));  % 应输出 [24, 100, 2]


y_s = (B +100) * sin(pi / 100 * t);


uav_trajectory(:,:,1) =  repmat(x_l, 3, 1);

uav_trajectory(2,:,2) =  zeros(1, time_slots);
uav_trajectory(1,:,2) =  y_s;
uav_trajectory(3,:,2) = -y_s;

uav_trajectory = uav_trajectory +100;  %轨迹居中
user_trajectory = user_trajectory +100;

users_x = user_trajectory(:,:,1);  %相邻间隙速度达到了25m
users_y = user_trajectory(:,:,2);
uav_x = uav_trajectory(:,:,1);
uav_y = uav_trajectory(:,:,2);


%save('myMatrice_s.mat', 'users_x', 'users_y','uav_x','uav_y');

end






