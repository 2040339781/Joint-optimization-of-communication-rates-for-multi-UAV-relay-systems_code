% 定义参数
I = 4; % 行数
M = 2; % 列数
P = I / M; % 每列需要的1的数量

% 定义 cost_matrix
cost_matrix = [
    10, 20;
    15, 25;
    20, 30;
    25, 35
];

% 变量数量
num_vars = I * M + 1; % x 变量数 + eta

% 目标函数：最大化 eta，即最小化 -eta
f = zeros(num_vars, 1);
f(end) = -1; % eta 的系数为 -1

% Big M 的取值
bigM = max(cost_matrix(:));

% 不等式约束
num_constraints = I * M;
Aineq = zeros(num_constraints, num_vars);
bineq = zeros(num_constraints, 1);

constraint_idx = 1;

for i = 1:I
    for j = 1:M
        idx = (j - 1) * I + i; % 展平后的 x_{ij} 索引
        % eta - cost_matrix_{ij} + M * (1 - x_{ij}) >= 0
        Aineq(constraint_idx, idx) = -bigM;     % 对应于 -M * x_{ij}
        Aineq(constraint_idx, end) = -1;        % eta 的系数为 -1
        bineq(constraint_idx) = -cost_matrix(i, j) + bigM; % 右侧为 -cost_matrix_{ij} + M
        constraint_idx = constraint_idx + 1;
    end
end


% 等式约束
% 每行有且仅有一个 1
Aeq1 = [kron(eye(I), ones(1, M)), zeros(I, 1)];
beq1 = ones(I, 1);

% 每列有且仅有 P 个 1
Aeq2 = [kron(ones(1, I), eye(M)), zeros(M, 1)];
beq2 = P * ones(M, 1);

% 合并等式约束
Aeq = [Aeq1; Aeq2];
beq = [beq1; beq2];

% 变量下界
lb = zeros(num_vars, 1);

% 变量上界
ub = ones(num_vars, 1);
ub(end) = max(cost_matrix(:)); % eta 的上界

% 整数变量索引
intcon = 1:(I*M); % x 变量为整数变量

% 设置优化选项
options = optimoptions('intlinprog', 'Display', 'off');

% 求解整数规划问题
[sol, fval, exitflag] = intlinprog(f, intcon, Aineq, bineq, Aeq, beq, lb, ub, options);

% 提取并显示结果
if exitflag == 1
    x_opt = reshape(sol(1:I*M), I, M);
    eta_opt = sol(end);
    disp('最优分配矩阵 x_opt 为：');
    disp(x_opt);
    disp(['最小代价值（eta）为：', num2str(eta_opt)]);
else
    error('未找到可行解。');
end
