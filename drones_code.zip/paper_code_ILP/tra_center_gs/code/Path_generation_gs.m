function [users_x,users_y,uav_x,uav_y]=Path_generation_gs()

% 高斯-马尔科夫模型模拟用户位置随时间变化
rng(3);

num_users = 24;
num_time_slots = 100;

%% 参数设置
delta_t = 1;             % 时间间隔（秒）
area_size = 800;        % 模拟区域大小（米）
alpha = 0.8;             % 相关系数（0 <= alpha <= 1）

% 方向参数
mu_theta = 0;            % 方向平均值（弧度）
sigma_theta = pi;      % 方向标准差

% 速度参数
mu_v = 30;                % 速度平均值（米/秒）
sigma_v = 6;           % 速度标准差

% 速度限制（可选）
v_min = 20;             % 最小速度（米/秒）
v_max = 40;             % 最大速度（米/秒）

%% 初始化位置、速度和方向
% 初始化位置（均匀分布在区域内）
users_x = zeros(num_users, num_time_slots);
users_y = zeros(num_users, num_time_slots);
users_x(:,1) = area_size * rand(num_users,1);
users_y(:,1) = area_size * rand(num_users,1);

% 初始化速度（在 v_min 和 v_max 之间均匀随机分布）
v = zeros(num_users, num_time_slots);
v(:,1) = v_min + (v_max - v_min) * rand(num_users,1);

% 初始化方向（在 0 到 2*pi 之间均匀随机分布）
theta = zeros(num_users, num_time_slots);
theta(:,1) = 2 * pi * rand(num_users,1);

%% 模拟过程
for t = 2:num_time_slots
    % 生成高斯白噪声
    w_v = randn(num_users,1);
    w_theta = randn(num_users,1);
    
    % 更新速度
    v(:,t) = alpha * v(:,t-1) + (1 - alpha) * mu_v + sqrt(1 - alpha^2) * sigma_v .* w_v;
    % 限制速度在 [v_min, v_max] 之间
    v(:,t) = max(min(v(:,t), v_max), v_min);
    
    % 更新方向
    theta(:,t) = alpha * theta(:,t-1) + (1 - alpha) * mu_theta + sqrt(1 - alpha^2) * sigma_theta .* w_theta;
    % 将方向限制在 [0, 2*pi] 之间
    theta(:,t) = mod(theta(:,t), 2*pi);
    
    % 更新位置
    users_x(:,t) = users_x(:,t-1) + v(:,t) * delta_t .* cos(theta(:,t));
    users_y(:,t) = users_y(:,t-1) + v(:,t) * delta_t .* sin(theta(:,t));
    
    % 边界处理（反射模型）
    % X 方向
    idx_x_lower = users_x(:,t) < 0;
    idx_x_upper = users_x(:,t) > area_size;
    users_x(idx_x_lower,t) = -users_x(idx_x_lower,t);
    users_x(idx_x_upper,t) = 2 * area_size - users_x(idx_x_upper,t);
    theta(idx_x_lower | idx_x_upper,t) = pi - theta(idx_x_lower | idx_x_upper,t);
    
    % Y 方向
    idx_y_lower = users_y(:,t) < 0;
    idx_y_upper = users_y(:,t) > area_size;
    users_y(idx_y_lower,t) = -users_y(idx_y_lower,t);
    users_y(idx_y_upper,t) = 2 * area_size - users_y(idx_y_upper,t);
    theta(idx_y_lower | idx_y_upper,t) = -theta(idx_y_lower | idx_y_upper,t);
    
    % 将方向限制在 [0, 2*pi] 之间
    theta(:,t) = mod(theta(:,t), 2*pi);
end

users_x = users_x +100;
users_y = users_y +100;

% %初始化无人机轨迹
x_l = linspace(0, 800, 100);

uav_y = zeros(3,100);
uav_y(1,:) = 200 *sin(x_l/800 *pi);
uav_y(3,:) = -200 *sin(x_l/800 *pi);

uav_x = zeros(3,100);
uav_x(1,:) = x_l;
uav_x(2,:) = x_l;
uav_x(3,:) = x_l;

uav_x =  uav_x +100;
uav_y =  uav_y +450;

%save('myMatrices_gs.mat', 'users_x', 'users_y','uav_x','uav_y');

% hold on;
% 
% for j = 1:24
%     plot(users_x(j, :),users_y(j, :), 'r', 'LineWidth', 2);
% end
% 
% for j = 1:3
%     plot(uav_x(j, :),uav_y(j, :), 'r', 'LineWidth', 2);
% end
% 
% hold off;





