clear; 
close all; 
clc;



addpath('./code'); % 当前目录下

value_1 = main_test(50000,9.5)
value_2 = main_test(50000,8.5)
value_3 = main_test(16000,9.5)

rmpath('./code');

addpath('./code_pow'); % 当前目录下

value_1 = main_test(50000,9.5)
value_2 = main_test(50000,8.5)
value_3 = main_test(16000,9.5)

rmpath('./code_pow');


addpath('./code_group'); % 当前目录下

value_1 = main_test(50000,9.5)
value_2 = main_test(50000,8.5)
value_3 = main_test(16000,9.5)

rmpath('./code_group');


addpath('./code_tra'); % 当前目录下

value_1 = main_test(50000,9.5)
value_2 = main_test(50000,8.5)
value_3 = main_test(16000,9.5)

rmpath('./code_tra');
