clear; 
close all; 
clc;

addpath('./tra_s/code'); % 当前目录下

value_1_s = main_test(50000,9)
value_2_s = main_test(50000,10)
value_3_s = main_test(50000,13)
value_4_s = main_test(50000,15)
value_5_s = main_test(50000,17)
value_6_s = main_test(50000,20)
value_7_s = main_test(50000,9.5)
value_8_s = main_test(30000,9.5)
value_9_s = main_test(20000,9.5)

rmpath('./tra_s/code');


addpath('./tra_s/code_group'); % 当前目录下

value_1_s_group = main_test(50000,9)
value_2_s_group = main_test(50000,10)
value_3_s_group = main_test(50000,13)
value_4_s_group = main_test(50000,15)
value_5_s_group = main_test(50000,17)
value_6_s_group = main_test(50000,20)
value_7_s_group = main_test(50000,9.5)
value_8_s_group = main_test(30000,9.5)
value_9_s_group = main_test(20000,9.5)

rmpath('./tra_s/code_group');


addpath('./tra_s/code_tra'); % 当前目录下

value_1_s_tra = main_test(50000,9)
value_2_s_tra = main_test(50000,10)
value_3_s_tra = main_test(50000,13)
value_4_s_tra = main_test(50000,15)
value_5_s_tra = main_test(50000,17)
value_6_s_tra = main_test(50000,20)
value_7_s_tra = main_test(50000,9.5)
value_8_s_tra = main_test(30000,9.5)
value_9_s_tra = main_test(20000,9.5)

rmpath('./tra_s/code_tra');


addpath('./tra_s/code_pow'); % 当前目录下

value_1_s_pow = main_test(50000,9)
value_2_s_pow = main_test(50000,10)
value_3_s_pow = main_test(50000,13)
value_4_s_pow = main_test(50000,15)
value_5_s_pow = main_test(50000,17)
value_6_s_pow = main_test(50000,20)
value_7_s_pow = main_test(50000,9.5)
value_8_s_pow = main_test(30000,9.5)
value_9_s_pow = main_test(20000,9.5)

rmpath('./tra_s/code_pow');


addpath('./tras_gs/code'); % 当前目录下

value_1_gs = main_test(50000,9)
value_2_gs = main_test(50000,10)
value_3_gs = main_test(50000,13)
value_4_gs = main_test(50000,15)
value_5_gs = main_test(50000,17)
value_6_gs = main_test(50000,20)
value_7_gs = main_test(50000,9.5)
value_8_gs = main_test(30000,9.5)
value_9_gs = main_test(20000,9.5)

rmpath('./tras_gs/code');


addpath('./tras_gs/code_group'); % 当前目录下

value_1_gs_group = main_test(50000,9)
value_2_gs_group = main_test(50000,10)
value_3_gs_group = main_test(50000,13)
value_4_gs_group = main_test(50000,15)
value_5_gs_group = main_test(50000,17)
value_6_gs_group = main_test(50000,20)
value_7_gs_group = main_test(50000,9.5)
value_8_gs_group = main_test(30000,9.5)
value_9_gs_group = main_test(20000,9.5)

rmpath('./tras_gs/code_group');


addpath('./tras_gs/code_tra'); % 当前目录下

value_1_gs_tra = main_test(50000,9)
value_2_gs_tra = main_test(50000,10)
value_3_gs_tra = main_test(50000,13)
value_4_gs_tra = main_test(50000,15)
value_5_gs_tra = main_test(50000,17)
value_6_gs_tra = main_test(50000,20)
value_7_gs_tra = main_test(50000,9.5)
value_8_gs_tra = main_test(30000,9.5)
value_9_gs_tra = main_test(20000,9.5)

rmpath('./tras_gs/code_tra');


addpath('./tras_gs/code_pow'); % 当前目录下

value_1_gs_pow = main_test(50000,9)
value_2_gs_pow = main_test(50000,10)
value_3_gs_pow = main_test(50000,13)
value_4_gs_pow = main_test(50000,15)
value_5_gs_pow = main_test(50000,17)
value_6_gs_pow = main_test(50000,20)
value_7_gs_pow = main_test(50000,9.5)
value_8_gs_pow = main_test(30000,9.5)
value_9_gs_pow = main_test(20000,9.5)

rmpath('./tras_gs/code_pow');


addpath('./tras_center_gs/code'); % 当前目录下

value_1_center_gs = main_test(50000,9)
value_2_center_gs = main_test(50000,10)
value_3_center_gs = main_test(50000,13)
value_4_center_gs = main_test(50000,15)
value_5_center_gs = main_test(50000,17)
value_6_center_gs = main_test(50000,20)
value_7_center_gs = main_test(50000,9.5)
value_8_center_gs = main_test(30000,9.5)
value_9_center_gs = main_test(20000,9.5)

rmpath('./tras_center_gs/code');


addpath('./tras_center_gs/code_group'); % 当前目录下

value_1_center_gs_group = main_test(50000,9)
value_2_center_gs_group = main_test(50000,10)
value_3_center_gs_group = main_test(50000,13)
value_4_center_gs_group = main_test(50000,15)
value_5_center_gs_group = main_test(50000,17)
value_6_center_gs_group = main_test(50000,20)
value_7_center_gs_group = main_test(50000,9.5)
value_8_center_gs_group = main_test(30000,9.5)
value_9_center_gs_group = main_test(20000,9.5)

rmpath('./tras_center_gs/code_group');


addpath('./tras_center_gs/code_tra'); % 当前目录下

value_1_center_gs_tra = main_test(50000,9)
value_2_center_gs_tra = main_test(50000,10)
value_3_center_gs_tra = main_test(50000,13)
value_4_center_gs_tra = main_test(50000,15)
value_5_center_gs_tra = main_test(50000,17)
value_6_center_gs_tra = main_test(50000,20)
value_7_center_gs_tra = main_test(50000,9.5)
value_8_center_gs_tra = main_test(30000,9.5)
value_9_center_gs_tra = main_test(20000,9.5)

rmpath('./tras_center_gs/code_tra');


addpath('./tras_center_gs/code_pow'); % 当前目录下

value_1_center_gs_pow = main_test(50000,9)
value_2_center_gs_pow = main_test(50000,10)
value_3_center_gs_pow = main_test(50000,13)
value_4_center_gs_pow = main_test(50000,15)
value_5_center_gs_pow = main_test(50000,17)
value_6_center_gs_pow = main_test(50000,20)
value_7_center_gs_pow = main_test(50000,9.5)
value_8_center_gs_pow = main_test(30000,9.5)
value_9_center_gs_pow = main_test(20000,9.5)

rmpath('./tras_center_gs/code_pow');

